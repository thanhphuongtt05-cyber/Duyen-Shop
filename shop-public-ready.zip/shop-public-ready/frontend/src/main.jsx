import React,{useEffect,useState} from 'react';
import {createRoot} from 'react-dom/client';
import axios from 'axios';
import './style.css';

const API=import.meta.env.VITE_API_URL||'http://localhost:4000/api';
const money=n=>new Intl.NumberFormat('vi-VN',{style:'currency',currency:'VND'}).format(n);
function App(){
 const [products,setProducts]=useState([]),[cats,setCats]=useState([]),[q,setQ]=useState(''),[cat,setCat]=useState(''),[cart,setCart]=useState([]),[user,setUser]=useState(null),[view,setView]=useState('shop'),[auth,setAuth]=useState('login');
 const [form,setForm]=useState({email:'',password:'',name:''});
 useEffect(()=>{axios.get(API+'/categories').then(r=>setCats(r.data));load(); const u=localStorage.getItem('user');if(u)setUser(JSON.parse(u));},[]);
 function load(){axios.get(API+'/products',{params:{q,category:cat||undefined}}).then(r=>setProducts(r.data));}
 function login(e){e.preventDefault();axios.post(API+'/auth/'+(auth==='register'?'register':'login'),form).then(r=>{localStorage.setItem('token',r.data.token);localStorage.setItem('user',JSON.stringify(r.data.user));setUser(r.data.user);setView('shop')}).catch(e=>alert(e.response?.data?.message||'Có lỗi'))}
 function add(p){setCart(c=>{const x=c.find(i=>i.id===p.id);return x?c.map(i=>i.id===p.id?{...i,qty:i.qty+1}:i):[...c,{...p,qty:1}]})}
 function logout(){localStorage.clear();setUser(null)}
 async function checkout(){if(!user)return setView('auth'); if(!cart.length)return; const address=prompt('Địa chỉ giao hàng:');const phone=prompt('Số điện thoại:');if(!address||!phone)return;try{await axios.post(API+'/orders',{items:cart.map(x=>({productId:x.id,quantity:x.qty})),address,phone},{headers:{Authorization:'Bearer '+localStorage.getItem('token')}});alert('Đặt hàng thành công');setCart([]);setView('orders')}catch(e){alert(e.response?.data?.message||'Đặt hàng thất bại')}}
 return <div><header><b onClick={()=>setView('shop')} className="logo">SHOP</b><input value={q} onChange={e=>setQ(e.target.value)} onKeyDown={e=>e.key==='Enter'&&load()} placeholder="Tìm sản phẩm..."/><nav><button onClick={()=>setView('shop')}>Sản phẩm</button><button onClick={()=>setView('cart')}>🛒 {cart.reduce((a,b)=>a+b.qty,0)}</button>{user?<><button onClick={()=>setView('orders')}>Đơn hàng</button><span>Hi, {user.name}</span><button onClick={logout}>Đăng xuất</button></>:<button onClick={()=>setView('auth')}>Đăng nhập</button>}</nav></header>
 {view==='shop'&&<main><section className="hero"><div><h1>Mua sắm đơn giản.</h1><p>Sản phẩm chọn lọc, đặt hàng nhanh chóng.</p></div></section><div className="toolbar"><select value={cat} onChange={e=>{setCat(e.target.value);setTimeout(load,0)}}><option value="">Tất cả danh mục</option>{cats.map(c=><option key={c.id} value={c.id}>{c.name}</option>)}</select><button onClick={load}>Tìm kiếm</button></div><div className="grid">{products.map(p=><article className="card" key={p.id}><img src={p.image}/><div className="pad"><small>{p.category.name}</small><h3>{p.name}</h3><p>{p.description}</p><strong>{money(p.price)}</strong><div className="row"><span>Còn {p.stock}</span><button disabled={!p.stock} onClick={()=>add(p)}>Thêm vào giỏ</button></div></div></article>)}</div></main>}
 {view==='cart'&&<main className="narrow"><h2>Giỏ hàng</h2>{!cart.length?<p>Giỏ hàng đang trống.</p>:<>{cart.map(x=><div className="cart"><img src={x.image}/><div><b>{x.name}</b><p>{money(x.price)} × {x.qty}</p></div><button onClick={()=>setCart(c=>c.filter(i=>i.id!==x.id))}>Xóa</button></div>)}<h3>Tổng: {money(cart.reduce((a,b)=>a+b.price*b.qty,0))}</h3><button className="primary" onClick={checkout}>Đặt hàng</button></>}</main>}
 {view==='auth'&&<main className="narrow"><h2>{auth==='login'?'Đăng nhập':'Tạo tài khoản'}</h2><form onSubmit={login}>{auth==='register'&&<input placeholder="Họ tên" value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/>}<input required type="email" placeholder="Email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})}/><input required type="password" placeholder="Mật khẩu" value={form.password} onChange={e=>setForm({...form,password:e.target.value})}/><button className="primary">{auth==='login'?'Đăng nhập':'Đăng ký'}</button></form><button className="link" onClick={()=>setAuth(auth==='login'?'register':'login')}>{auth==='login'?'Chưa có tài khoản? Đăng ký':'Đã có tài khoản? Đăng nhập'}</button></main>}
 {view==='orders'&&<Orders/>}
 </div>
}
function Orders(){const [orders,setOrders]=useState([]);useEffect(()=>{axios.get(API+'/orders',{headers:{Authorization:'Bearer '+localStorage.getItem('token')}}).then(r=>setOrders(r.data))},[]);return <main className="narrow"><h2>Đơn hàng của tôi</h2>{orders.map(o=><div className="order" key={o.id}><b>#{o.id} · {o.status}</b><p>{money(o.total)} · {new Date(o.createdAt).toLocaleString('vi-VN')}</p><small>{o.address}</small></div>)}</main>}
createRoot(document.getElementById('root')).render(<App/>);
