require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { z } = require('zod');
const { PrismaClient } = require('@prisma/client');

const app = express();
const prisma = new PrismaClient();
const PORT = process.env.PORT || 4000;
const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) throw new Error('JWT_SECRET is required');

app.use(helmet());
app.use(cors({origin: process.env.CLIENT_URL || 'http://localhost:5173'}));
app.use(express.json({limit:'1mb'}));
app.use(rateLimit({windowMs: 15*60*1000, max: 300}));

function sign(user){ return jwt.sign({id:user.id,email:user.email,role:user.role},JWT_SECRET,{expiresIn:'2h'}); }
function auth(req,res,next){
  const token=(req.headers.authorization||'').replace('Bearer ','');
  try { req.user=jwt.verify(token,JWT_SECRET); next(); }
  catch { return res.status(401).json({message:'Unauthorized'}); }
}
function admin(req,res,next){ if(req.user.role!=='ADMIN') return res.status(403).json({message:'Admin only'}); next(); }

app.get('/api/health',(_,res)=>res.json({ok:true}));
app.get('/api/categories',async(_,res)=>res.json(await prisma.category.findMany({orderBy:{name:'asc'}})));
app.get('/api/products',async(req,res)=>{
  const q=String(req.query.q||'').trim();
  const category=Number(req.query.category||0);
  res.json(await prisma.product.findMany({
    where:{active:true,...(q?{OR:[{name:{contains:q}},{description:{contains:q}}]}:{}),...(category?{categoryId:category}:{})},
    include:{category:true}, orderBy:{createdAt:'desc'}
  }));
});
app.post('/api/auth/register',async(req,res)=>{
  const p=z.object({email:z.string().email(),password:z.string().min(8),name:z.string().min(2).max(80)}).parse(req.body);
  if(await prisma.user.findUnique({where:{email:p.email}})) return res.status(409).json({message:'Email đã tồn tại'});
  const user=await prisma.user.create({data:{...p,password:await bcrypt.hash(p.password,12)}});
  res.status(201).json({token:sign(user),user:{id:user.id,email:user.email,name:user.name,role:user.role}});
});
app.post('/api/auth/login',async(req,res)=>{
  const p=z.object({email:z.string().email(),password:z.string()}).parse(req.body);
  const user=await prisma.user.findUnique({where:{email:p.email}});
  if(!user || !(await bcrypt.compare(p.password,user.password))) return res.status(401).json({message:'Email hoặc mật khẩu không đúng'});
  res.json({token:sign(user),user:{id:user.id,email:user.email,name:user.name,role:user.role}});
});
app.get('/api/orders',auth,async(req,res)=>res.json(await prisma.order.findMany({where:{userId:req.user.id},include:{items:{include:{product:true}}},orderBy:{createdAt:'desc'}})));
app.post('/api/orders',auth,async(req,res)=>{
  const p=z.object({items:z.array(z.object({productId:z.number().int().positive(),quantity:z.number().int().positive()})).min(1),address:z.string().min(5),phone:z.string().min(8)}).parse(req.body);
  const order=await prisma.$transaction(async tx=>{
    let total=0; const rows=[];
    for(const item of p.items){
      const product=await tx.product.findUnique({where:{id:item.productId}});
      if(!product || !product.active) throw new Error('Sản phẩm không tồn tại');
      if(product.stock<item.quantity) throw new Error(`Không đủ tồn kho: ${product.name}`);
      await tx.product.update({where:{id:product.id},data:{stock:{decrement:item.quantity}}});
      total+=product.price*item.quantity;
      rows.push({productId:product.id,quantity:item.quantity,price:product.price});
    }
    return tx.order.create({data:{userId:req.user.id,total,address:p.address,phone:p.phone,items:{create:rows}},include:{items:true}});
  });
  res.status(201).json(order);
});
app.get('/api/admin/orders',auth,admin,async(_,res)=>res.json(await prisma.order.findMany({include:{user:true,items:{include:{product:true}}},orderBy:{createdAt:'desc'}})));
app.post('/api/admin/products',auth,admin,async(req,res)=>{
  const p=z.object({name:z.string().min(2),description:z.string(),price:z.number().int().positive(),stock:z.number().int().nonnegative(),image:z.string().url(),categoryId:z.number().int().positive()}).parse(req.body);
  const slug=p.name.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]+/g,'-')+'-'+Date.now();
  res.status(201).json(await prisma.product.create({data:{...p,slug}}));
});
app.patch('/api/admin/orders/:id/status',auth,admin,async(req,res)=>{
  const p=z.object({status:z.enum(['PENDING','CONFIRMED','SHIPPING','DELIVERED','CANCELLED'])}).parse(req.body);
  res.json(await prisma.order.update({where:{id:Number(req.params.id)},data:{status:p.status}}));
});
app.use((err,req,res,next)=>{console.error(err);res.status(400).json({message:err.message||'Bad request'});});
app.listen(PORT,()=>console.log(`API running on ${PORT}`));
