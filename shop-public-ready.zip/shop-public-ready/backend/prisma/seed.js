const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');
const prisma = new PrismaClient();

async function main() {
  const adminPassword = await bcrypt.hash('Admin123!', 12);
  await prisma.user.upsert({
    where: { email: 'admin@example.com' },
    update: {},
    create: { email: 'admin@example.com', name: 'Admin', password: adminPassword, role: 'ADMIN' }
  });

  const names = ['Thời trang', 'Điện tử', 'Gia dụng'];
  const categories = {};
  for (const name of names) {
    categories[name] = await prisma.category.upsert({
      where: { name }, update: {}, create: { name }
    });
  }

  const products = [
    ['Áo thun Basic','ao-thun-basic','Áo thun cotton mặc hằng ngày',199000,50,'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=900&q=80','Thời trang'],
    ['Tai nghe Bluetooth','tai-nghe-bluetooth','Tai nghe không dây tiện dụng',599000,25,'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=900&q=80','Điện tử'],
    ['Bình giữ nhiệt','binh-giu-nhiet','Bình inox giữ nhiệt 500ml',249000,40,'https://images.unsplash.com/photo-1602143407151-7111542de6e8?auto=format&fit=crop&w=900&q=80','Gia dụng']
  ];
  for (const [name,slug,description,price,stock,image,cat] of products) {
    await prisma.product.upsert({
      where:{slug}, update:{}, create:{name,slug,description,price,stock,image,categoryId:categories[cat].id}
    });
  }
}
main().finally(()=>prisma.$disconnect());
